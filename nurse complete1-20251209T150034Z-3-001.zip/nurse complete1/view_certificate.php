<?php
session_start();
require_once 'db.php';

// Only admins may view nurse certificates
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'Admin') {
    header('Location: login.php');
    exit;
}

$userId = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
if ($userId <= 0) {
    http_response_code(400);
    echo "Invalid user id.";
    exit;
}

// Fetch the certificate path for the nurse
$stmt = $pdo->prepare("SELECT certificate_path FROM users WHERE id = ? AND role = 'Nurse' LIMIT 1");
$stmt->execute([$userId]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$row || empty($row['certificate_path'])) {
    http_response_code(404);
    echo "Certificate not found.";
    exit;
}

// Allow absolute remote URLs (legacy support)
$certPath = trim($row['certificate_path']);
if (preg_match('#^https?://#i', $certPath)) {
    header('Location: ' . $certPath);
    exit;
}

$relativePath = str_replace(['\\', '/'], DIRECTORY_SEPARATOR, ltrim($certPath, '/\\'));
$baseDir = realpath(__DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'certificates');
$filePath = realpath(__DIR__ . DIRECTORY_SEPARATOR . $relativePath);

// Fallback: if realpath failed (e.g., non-ASCII or odd characters), try simple join inside baseDir
if ($filePath === false && $baseDir !== false) {
    $fallback = $baseDir . DIRECTORY_SEPARATOR . basename($relativePath);
    if (is_file($fallback)) {
        $filePath = $fallback;
    }
}

// Security: ensure the resolved file is inside the certificates folder
if ($filePath === false || $baseDir === false || strpos($filePath, $baseDir) !== 0 || !is_file($filePath)) {
    http_response_code(404);
    echo "Certificate file is missing or path is invalid.";
    exit;
}

// Prefer redirecting to the actual file so the browser handles display/download naturally
$relativeWeb = str_replace(DIRECTORY_SEPARATOR, '/', trim(str_replace(['\\', '/'], '/', $certPath), '/'));
$scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/\\');
$publicUrl = ($scriptDir === '' ? '' : $scriptDir) . '/' . implode('/', array_map('rawurlencode', explode('/', $relativeWeb)));
header('Location: ' . $publicUrl);
exit;

// Determine mime type for proper display
// Fallback: stream directly (should rarely be hit if redirect above works)
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = $finfo ? finfo_file($finfo, $filePath) : 'application/octet-stream';
if ($finfo) finfo_close($finfo);

header('Content-Type: ' . $mime);
header('Content-Disposition: inline; filename="' . basename($filePath) . '"');
$size = @filesize($filePath);
if ($size !== false) {
    header('Content-Length: ' . $size);
}
readfile($filePath);
exit;
