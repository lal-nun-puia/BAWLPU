<?php
require 'db.php';
$cols = $pdo->query('DESCRIBE bookings')->fetchAll(PDO::FETCH_COLUMN, 0);
echo 'Columns: ' . implode(', ', $cols) . PHP_EOL;
echo 'Has status: ' . (in_array('status', $cols) ? 'yes' : 'no') . PHP_EOL;
echo 'Has request_id: ' . (in_array('request_id', $cols) ? 'yes' : 'no') . PHP_EOL;

// Try the index.php query pattern safely
$stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE nurse_id = ? AND status = 'Applied'");
$stmt->execute([0]);
echo 'Count check OK: ' . $stmt->fetchColumn() . PHP_EOL;

