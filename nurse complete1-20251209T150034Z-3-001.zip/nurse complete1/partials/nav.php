<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../db.php';

$logged_in = isset($_SESSION['user_id']) || isset($_SESSION['user']);
$user_id = $_SESSION['user_id'] ?? ($_SESSION['user']['user_id'] ?? null);
$user_role = $_SESSION['user_role'] ?? ($_SESSION['user']['role'] ?? null);
$user_name = $_SESSION['user_name'] ?? ($_SESSION['user']['name'] ?? null);

$applied_jobs_count = 0;
if ($logged_in && $user_role === 'Nurse') {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE nurse_id = ? AND status = 'Applied'");
        $stmt->execute([$user_id]);
        $applied_jobs_count = (int)$stmt->fetchColumn();
    } catch (Exception $e) { /* ignore */ }
}
?>

<header class="topbar">
  <div class="brand" style="display:flex;align-items:center;gap:12px;">
    <div class="hamburger" onclick="toggleNav()">
      <span></span>
      <span></span>
      <span></span>
    </div>
    <h1 style="margin:0;font-size:22px;">BAWLPU</h1>
  </div>
  <div class="header-actions" style="display:flex;align-items:center;gap:10px;">
    <?php if(!$logged_in): ?>
      <a href="login.php" class="btn btn-outline">Login</a>
    <?php else: ?>
      <a href="logout.php" class="btn btn-outline">Logout</a>
    <?php endif; ?>
    <button id="themeToggle" class="btn btn-outline" type="button">Toggle Theme</button>
  </div>
</header>

<div class="overlay" id="overlay" onclick="closeNav()"></div>
<nav id="navMenu">
  <?php if($user_role === 'Client'): ?>
  <div class="nav-search">
    <form method="GET" action="search_nurse.php">
      <input type="text" name="skill" placeholder="Search by skill">
      <input type="text" name="location" placeholder="Location">
      <button type="submit">Search</button>
    </form>
  </div>
  <?php endif; ?>
  <?php if($logged_in): ?>
    <div class="nav-section">
      <h3>Main</h3>
      <a href="index.php">Home</a>
      <a href="dashboard.php">Dashboard</a>
      <a href="profile.php">Profile</a>
    </div>
    <?php if($user_role == 'Client'): ?>
      <div class="nav-section">
        <h3>Client</h3>
        <a href="booking.php">Bookings</a>
        <a href="search_nurse.php">Search Nurses</a>
        <a href="notifications.php">Notifications</a>
        <a href="feedback.php">Feedback</a>
      </div>
    <?php elseif($user_role == 'Nurse'): ?>
      <div class="nav-section">
        <h3>Nurse</h3>
        <a href="get_booking.php">Applied Jobs<?php if($applied_jobs_count>0) echo '<span class="badge">'.$applied_jobs_count.'</span>'; ?></a>
        <a href="babysitting.php">Babysitting Jobs</a>
        <a href="patientcare.php">Patient Care Jobs</a>
        <a href="labtesting.php">Lab Testing Jobs</a>
        <a href="elderlycare.php">Elderly Care Jobs</a>
        <a href="notifications.php">Notifications</a>
        <a href="feedback.php">Feedback</a>
      </div>
    <?php elseif($user_role == 'Admin'): ?>
      <div class="nav-section">
        <h3>Admin</h3>
        <a href="admin_dashboard.php">Dashboard</a>
        <a href="view_users.php">Manage Users</a>
        <a href="admin_services.php">Manage Services</a>
        <a href="admins_booking.php">All Bookings</a>
        <a href="admin_requests.php">All Requests</a>
        <a href="admin_notifications.php">Broadcast</a>
        <a href="notifications.php">Notifications</a>
      </div>
    <?php endif; ?>
    <div class="nav-section">
      <h3>Account</h3>
      <a href="logout.php">Logout</a>
    </div>
  <?php else: ?>
    <div class="nav-section">
      <h3>Welcome</h3>
      <a href="index.php">Home</a>
      <a href="login.php">Login</a>
      <a href="register.php">Register</a>
    </div>
  <?php endif; ?>
</nav>
