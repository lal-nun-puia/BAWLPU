<?php
session_start();
require_once 'db.php';
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'Admin') {
  header('Location: login.php');
  exit;
}

// Handle role update / delete
if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (isset($_POST['delete_user'])) {
    $uid = (int)$_POST['user_id'];
    $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$uid]);
  } elseif (isset($_POST['update_status'])) {
    $uid = (int)$_POST['user_id'];
    $newStatus = $_POST['approval_status'] ?? '';
    $allowed = ['Pending','Approved','Rejected'];
    if (in_array($newStatus, $allowed, true)) {
      $stmt = $pdo->prepare("UPDATE users SET approval_status=? WHERE id=? AND role='Nurse'");
      $stmt->execute([$newStatus,$uid]);
    }
  }
  header('Location: view_users.php');
  exit;
}

$roleFilter = $_GET['role'] ?? '';
$sql = "SELECT id,name,email,role,service,approval_status,certificate_path FROM users" . ($roleFilter?" WHERE role=?":"") . " ORDER BY id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($roleFilter?[$roleFilter]:[]);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Manage Users</title>
  <link rel="stylesheet" href="assets/styles.css">
  <script src="assets/theme.js"></script>
</head>
<body>
<?php include 'partials/nav.php'; ?>
<div class="container" style="max-width:1000px;margin:80px auto 20px;">
  <h2>Manage Users</h2>
  <form method="get" class="flex" style="margin:10px 0; gap:8px; align-items:center;">
    <label for="role">Filter by role:</label>
    <select id="role" name="role" onchange="this.form.submit()">
      <option value="">All Roles</option>
      <option value="Client" <?= $roleFilter==='Client'?'selected':'' ?>>Client</option>
      <option value="Nurse" <?= $roleFilter==='Nurse'?'selected':'' ?>>Nurse</option>
      <option value="Admin" <?= $roleFilter==='Admin'?'selected':'' ?>>Admin</option>
    </select>
    <noscript>
      <button class="btn btn-primary" type="submit">Filter</button>
    </noscript>
  </form>

  <div class="flex" style="gap:8px; margin:6px 0 16px 0;">
    <a class="btn btn-outline" href="view_users.php">All</a>
    <a class="btn btn-outline" href="view_users.php?role=Client">Clients</a>
    <a class="btn btn-outline" href="view_users.php?role=Nurse">Nurses</a>
    <a class="btn btn-outline" href="view_users.php?role=Admin">Admins</a>
  </div>

  <table class="table">
    <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Certificate</th><th>Actions</th></tr></thead>
    <tbody>
      <?php foreach($users as $u): ?>
      <?php
        $isLabTech = ($u['role'] === 'Nurse') && strcasecmp($u['service'] ?? '', 'LabTesting') === 0;
        $displayRole = $isLabTech ? 'Lab Technician' : ($u['role'] ?? '');
      ?>
      <tr>
        <td><?= (int)$u['id'] ?></td>
        <td><?= htmlspecialchars($u['name']) ?></td>
        <td><?= htmlspecialchars($u['email']) ?></td>
        <td><?= htmlspecialchars($displayRole) ?></td>
        <td><?= htmlspecialchars($u['role']==='Nurse' ? ($u['approval_status'] ?? 'Pending') : 'Approved') ?></td>
        <td>
          <?php if($u['role']==='Nurse' && !empty($u['certificate_path'])): ?>
            <a class="btn btn-outline" href="view_certificate.php?user_id=<?= (int)$u['id'] ?>" target="_blank" rel="noopener">View</a>
          <?php else: ?>
            <span>--</span>
          <?php endif; ?>
        </td>
        <td>
          <?php if($u['role']==='Nurse'): ?>
          <form method="post" class="flex" style="gap:6px; margin-bottom:6px;">
            <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
            <select name="approval_status">
              <option value="Pending" <?= ($u['approval_status'] ?? '')==='Pending'?'selected':'' ?>>Pending</option>
              <option value="Approved" <?= ($u['approval_status'] ?? '')==='Approved'?'selected':'' ?>>Approved</option>
              <option value="Rejected" <?= ($u['approval_status'] ?? '')==='Rejected'?'selected':'' ?>>Rejected</option>
            </select>
            <button class="btn btn-primary" name="update_status" type="submit">Set</button>
          </form>
          <?php endif; ?>
          <form method="post" onsubmit="return confirm('Delete this user?');">
            <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
            <button class="btn btn-danger" name="delete_user" type="submit">Delete</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<script src="assets/nav.js"></script>
</body>
</html>
