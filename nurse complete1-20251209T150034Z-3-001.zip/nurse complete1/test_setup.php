<?php
require_once 'db.php';

try {
    // Create test nurse
    $password = password_hash('testpass', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO users (name, email, password, phone, address, role, skills, service, salary, experience, location, bio) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute(['Test Nurse', 'nurse@test.com', $password, '1234567890', 'Test Address', 'Nurse', 'Nursing', 'PatientCare', 500, 5, 'Test City', 'Test Bio']);
    echo "Nurse user created\n";

    // Create test client request
    $stmt = $pdo->prepare('INSERT INTO client_requests (client_id, service_type, name, age, address, phone, notes, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([1, 'PatientCare', 'Test Patient', 30, 'Test Address', '0987654321', 'Test notes', 'Pending']);
    echo "Client request created\n";

    // Get the last inserted request ID
    $request_id = $pdo->lastInsertId();
    echo "Request ID: $request_id\n";

} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
