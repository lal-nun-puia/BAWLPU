const registerButton = document.getElementById('register')
const loginButton = document.getElementById('login')
const container = document.getElementById('container')
 

if (registerButton && container) {
  registerButton.onclick = function(){
     container.className = 'active'
  }
}
if (loginButton && container) {
  loginButton.onclick = function(){
     container.className = 'close'
  }
}

