function toggleNav(){
  var nav = document.getElementById('navMenu');
  var overlay = document.getElementById('overlay');
  var hamburger = document.querySelector('.hamburger');
  if(!nav||!overlay||!hamburger) return;
  nav.classList.toggle('active');
  overlay.style.display = nav.classList.contains('active') ? 'block' : 'none';
  hamburger.classList.toggle('active');
}
function closeNav(){
  var nav = document.getElementById('navMenu');
  var overlay = document.getElementById('overlay');
  var hamburger = document.querySelector('.hamburger');
  if(!nav||!overlay||!hamburger) return;
  nav.classList.remove('active');
  overlay.style.display = 'none';
  hamburger.classList.remove('active');
}
