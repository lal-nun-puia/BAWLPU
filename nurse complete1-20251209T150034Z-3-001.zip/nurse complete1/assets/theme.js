// Apply saved theme on load across all pages
(function(){
  try {
    var root = document.documentElement;
    var saved = localStorage.getItem('theme');
    if (saved === 'dark') {
      root.classList.add('theme-dark');
      return;
    }
    // If no saved preference, follow system preference (defaults to dark when user prefers dark)
    if (!saved && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      root.classList.add('theme-dark');
    }
  } catch (e) {}
})();
