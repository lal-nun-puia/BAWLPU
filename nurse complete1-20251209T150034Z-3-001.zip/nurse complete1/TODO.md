.
- [x] Add email validation in register.php to only allow @gmail.com domains
- [x] Add phone number validation in register.php to exactly 10 digits numeric
- [x] Add email validation in login.php to only allow @gmail.com domains before login attempt
- [ ] Test the validations by attempting invalid inputs
