# Add Notification Badge for Applied Jobs

## Information Gathered
- Nurses view applied jobs in `get_booking.php`, which shows bookings with status 'Applied'.
- Navigation in `index.php` has a link to "Applied Jobs" for nurses.
- No current indication of pending applications count.
- Notifications system exists but is separate; this task focuses on a simple count badge for applied jobs.

## Plan
- Modify `index.php` to fetch the count of applied bookings for nurses.
- Add a badge next to "Applied Jobs" in the navigation showing the count if >0.
- Add CSS styling for the badge.
- No changes needed to `get_booking.php` as the list itself shows the jobs.

## Dependent Files
- `index.php`: Add query, modify nav link, add CSS.

## Followup Steps
- Test as nurse user to verify badge appears and updates correctly.
- Ensure count decreases when jobs are accepted/rejected.
