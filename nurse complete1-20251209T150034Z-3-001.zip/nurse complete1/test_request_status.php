<?php
require 'db.php';
$result = $pdo->query('SELECT COUNT(*) as count FROM client_requests WHERE status="Applied"')->fetch(PDO::FETCH_ASSOC);
echo 'Applied requests: ' . $result['count'] . PHP_EOL;
$result = $pdo->query('SELECT COUNT(*) as count FROM bookings WHERE status="Applied"')->fetch(PDO::FETCH_ASSOC);
echo 'Applied bookings: ' . $result['count'] . PHP_EOL;
?>
